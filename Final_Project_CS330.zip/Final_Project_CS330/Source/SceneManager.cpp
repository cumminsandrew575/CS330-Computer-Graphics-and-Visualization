///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <GLFW/glfw3.h>
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3 && 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	bReturn = CreateGLTexture(
		"textures/forrest_ground_01_diff_4k.jpg",
		"forrest_floor");

	bReturn = CreateGLTexture(
		"textures/metal_plate_diff_4k.jpg",
		"chain_hook_metal");

	bReturn = CreateGLTexture(
		"textures/Metal029.png",
		"cooking_pot_metal");

	bReturn = CreateGLTexture(
		"textures/pine_bark_diff_4k.jpg",
		"tripod_wood");

	bReturn = CreateGLTexture(
		"textures/Background.jpg",
		"backdrop");

	bReturn = CreateGLTexture(
		"textures/Rope.jpg",
		"rope");

	bReturn = CreateGLTexture(
		"textures/Stone.jpg",
		"stone");


	

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

void SceneManager::DefineObjectMaterials()
{
	// material to highlight the ground
	OBJECT_MATERIAL groundMaterial;
	groundMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f);
	groundMaterial.specularColor = glm::vec3(0.04f, 0.04f, 0.04f);
	groundMaterial.shininess = 8.0;
	groundMaterial.tag = "ground";
	m_objectMaterials.push_back(groundMaterial);

	// material for the stone cirlce surrounding the fire
	OBJECT_MATERIAL stoneMaterial;
	stoneMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	stoneMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	stoneMaterial.shininess = 10.0;
	stoneMaterial.tag = "stone";
	m_objectMaterials.push_back(stoneMaterial);

	// shiny gray with a matte finish to accunuate the walls
	OBJECT_MATERIAL wallMaterial;
	wallMaterial.diffuseColor = glm::vec3(0.85f, 0.85f, 0.85f);
	wallMaterial.specularColor = glm::vec3(0.02f, 0.02f, 0.02f);
	wallMaterial.shininess = 6.0;
	wallMaterial.tag = "wall";
	m_objectMaterials.push_back(wallMaterial);


	// wood material for tripod + logs
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.55f, 0.27f, 0.07f);
	woodMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	woodMaterial.shininess = 12.0;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// metal material for pot + chain + hook
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.32f);
	metalMaterial.specularColor = glm::vec3(0.7f, 0.7f, 0.7f);
	metalMaterial.shininess = 64.0;
	metalMaterial.tag = "metal";
	m_objectMaterials.push_back(metalMaterial);
}

// SetUpSceneLights function is designed to bring out the features of the campfire

void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Directional sunlight
	m_pShaderManager->setVec3Value("directionalLight.direction", -0.3f, -1.0f, -0.2f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.3f, 0.24f, 0.14f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.8f, 0.7f, 0.5f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.8f, 0.7f, 0.5f);
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// Point light above campfire
	m_pShaderManager->setVec3Value("pointLights[0].position", 0.0f, 7.0f, 0.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.05f, 0.05f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.3f, 0.3f, 0.6f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.3f, 0.3f, 0.6f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// Fire glow point light low near ground
	m_pShaderManager->setVec3Value("pointLights[1].position", 0.0f, 0.6f, 0.0f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.04f, 0.02f, 0.01f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 1.0f, 0.5f, 0.2f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.12f, 0.06f, 0.03f);
	m_pShaderManager->setFloatValue("pointLights[1].constant", 1.0f);
	m_pShaderManager->setFloatValue("pointLights[1].linear", 0.42f);
	m_pShaderManager->setFloatValue("pointLights[1].quadratic", 0.56f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// 3 spotlights to highlight the tripod 
	m_pShaderManager->setVec3Value("spotLights[0].position", 0.0f, 6.0f, 8.0f);
	m_pShaderManager->setVec3Value("spotLights[0].direction", 0.0f, -1.0f, -1.0f);
	m_pShaderManager->setVec3Value("spotLights[0].ambient", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("spotLights[0].diffuse", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("spotLights[0].specular", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setFloatValue("spotLights[0].cutOff", glm::cos(glm::radians(25.0f)));
	m_pShaderManager->setFloatValue("spotLights[0].outerCutOff", glm::cos(glm::radians(35.0f)));
	m_pShaderManager->setBoolValue("spotLights[0].bActive", true);

	m_pShaderManager->setVec3Value("spotLights[1].position", -8.0f, 6.0f, 0.0f);
	m_pShaderManager->setVec3Value("spotLights[1].direction", 1.0f, -1.0f, 0.0f);
	m_pShaderManager->setVec3Value("spotLights[1].ambient", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("spotLights[1].diffuse", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("spotLights[1].specular", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setFloatValue("spotLights[1].cutOff", glm::cos(glm::radians(25.0f)));
	m_pShaderManager->setFloatValue("spotLights[1].outerCutOff", glm::cos(glm::radians(35.0f)));
	m_pShaderManager->setBoolValue("spotLights[1].bActive", true);

	m_pShaderManager->setVec3Value("spotLights[2].position", 8.0f, 6.0f, 0.0f);
	m_pShaderManager->setVec3Value("spotLights[2].direction", -1.0f, -1.0f, 0.0f);
	m_pShaderManager->setVec3Value("spotLights[2].ambient", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("spotLights[2].diffuse", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("spotLights[2].specular", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setFloatValue("spotLights[2].cutOff", glm::cos(glm::radians(25.0f)));
	m_pShaderManager->setFloatValue("spotLights[2].outerCutOff", glm::cos(glm::radians(35.0f)));
	m_pShaderManager->setBoolValue("spotLights[2].bActive", true);


	m_pShaderManager->setBoolValue("spotLight.bActive", false);
}




void SceneManager::FireLightFlicker()
{
	// time-based flicker using glfwGetTime to give a fire effect
	float t = static_cast<float>(glfwGetTime());
	float base = 0.85f;
	float wiggle = 0.15f * (0.6f * sinf(t * 8.7f) + 0.4f * sinf(t * 13.9f));
	float intensity = glm::clamp(base + wiggle, 0.65f, 1.1f);

	m_pShaderManager->setVec3Value("pointLights[1].diffuse",
		1.0f * intensity, 0.5f * intensity, 0.2f * intensity);
	m_pShaderManager->setVec3Value("pointLights[1].specular",
		0.12f * intensity, 0.06f * intensity, 0.03f * intensity);
}


void SceneManager::PrepareScene()
{
	// load the texture image files for the textures applied
	// to objects in the 3D scene
	LoadSceneTextures();
	// define the materials that will be used for the objects
	// in the 3D scene
	DefineObjectMaterials();
	// add the light sources for the 3D scene
	SetupSceneLights();
	// add accent lighting to the give the fire effect
	FireLightFlicker();

	

	
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
}



 /***********************************************************
   *  RenderScene()
   *
   *  This method is used for rendering the 3D scene by
   *  transforming and drawing the basic 3D shapes
   ***********************************************************/
void SceneManager::RenderScene()
{
	// background of the campfire scene
	RenderForrestFloor();
	RenderBackDrop();
	RenderLeftWall();
	RenderRightWall();

	// Tripod + pot setup
	RenderTripodLegOne();
	RenderTripodLegTwo();
	RenderTripodLegThree();
	RenderRopeLash();
	RenderChain();
	RenderHook();
	RenderCookingPot();

	// Stone circle
	RenderStone1();
	RenderStone2();
	RenderStone3();
	RenderStone4();
	RenderStone5();
	RenderStone6();
	RenderStone7();
	RenderStone8();

	// Fire setup
	RenderFirewood1();
	RenderFirewood2();
	RenderFirewood3();
	RenderFlames();

	//Sitting logs
	RenderSittingLog1();
	RenderSittingLog2();
}



/***********************************************************
 *  RenderForrestFloor()
 *
 *  This method is called to render the shape for the forrest
 *  scene floor object.
 ***********************************************************/
	void SceneManager::RenderForrestFloor()
	{

		// declare the variables for the transformations
		glm::vec3 scaleXYZ;
		float XrotationDegrees = 0.0f;
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;
		glm::vec3 positionXYZ;

		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(20.0f, 1.0f, 20.0f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		// set texture + tiling + material
		SetShaderTexture("forrest_floor");
		SetTextureUVScale(6.0, 6.0);
		SetShaderMaterial("ground");


		// draw the mesh with transformation values
		m_basicMeshes->DrawPlaneMesh();
	}

	/****************************************************************/

	/***********************************************************
	*  RenderBackdrop()
	*
	*  This method is called to render the shapes for the scene
	*  mountain backdrop object.
	***********************************************************/
	void SceneManager::RenderBackDrop()
	{
		// declare the variables for the transformations
		glm::vec3 scaleXYZ;
		float XrotationDegrees = 0.0f;
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;
		glm::vec3 positionXYZ;

		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(20.0f, 1.0f, 20.0f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 90.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(0.0f, 12.0f, -12.0f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		SetShaderTexture("backdrop");
		SetTextureUVScale(3.0, 1.6);
		SetShaderMaterial("wall");


		// draw the mesh with transformation values
		m_basicMeshes->DrawPlaneMesh();
	}

	/***********************************************************
	*  RenderLeftWall()
	*
	*  This method is called to render the shapes for the scene
	*  mountain wall object.
	***********************************************************/
	void SceneManager::RenderLeftWall()
	{
		// declare the variables for the transformations
		glm::vec3 scaleXYZ;
		float XrotationDegrees = 0.0f;
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;
		glm::vec3 positionXYZ;

		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 180.0f;
		YrotationDegrees = 90.0f;
		ZrotationDegrees = 90.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(-20.0f, 10.0f, 0.0f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		SetShaderTexture("backdrop");
		SetTextureUVScale(3.0, 1.6);
		SetShaderMaterial("wall");


		// draw the mesh with transformation values
		m_basicMeshes->DrawPlaneMesh();
	}

	/***********************************************************
	 *  RenderRightWall()
	 *
	 *  This method is called to render the shape for the scene
	 *  mountain wall object.
	 ***********************************************************/
	void SceneManager::RenderRightWall()
	{
		// declare the variables for the transformations
		glm::vec3 scaleXYZ;
		float XrotationDegrees = 0.0f;
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;
		glm::vec3 positionXYZ;

		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 180.0f;
		YrotationDegrees = 90.0f;
		ZrotationDegrees = 90.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(18.0f, 10.0f, 0.0f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		
		SetShaderTexture("backdrop");
		SetTextureUVScale(3.0, 1.6);
		SetShaderMaterial("wall");


		// draw the mesh with transformation values
		m_basicMeshes->DrawPlaneMesh();

	}
	/***********************************************************
	*  RenderTripodLegOne()
	*
	*  This method is called to render the shape for the
	*  wood tripod leg
	***********************************************************/
	void SceneManager::RenderTripodLegOne()
	{
		// declare the variables for the transformations
		glm::vec3 scaleXYZ;
		float XrotationDegrees = 0.0f;
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;
		glm::vec3 positionXYZ;

		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(0.1f, 8.5f, 0.1f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 28.0f;
		YrotationDegrees = 45.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(-2.5f, 0.0f, -2.5f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);
		
		
		SetShaderTexture("tripod_wood");
		SetTextureUVScale(1.0, 1.0);
		SetShaderMaterial("wood");


		// draw the mesh with transformation values
		m_basicMeshes->DrawCylinderMesh();
	}
	/***********************************************************
	*  RenderTripodLegTwo()
	*
	*  This method is called to render the shape for the
	*  wood tripod leg
	***********************************************************/
	void SceneManager::RenderTripodLegTwo()
	{
		// declare the variables for the transformations
		glm::vec3 scaleXYZ;
		float XrotationDegrees = 0.0f;
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;
		glm::vec3 positionXYZ;

		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(0.1f, 8.5f, 0.1f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 28.0f;
		YrotationDegrees = 315.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(2.5f, 0.0f, -2.5f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);
		
		SetShaderTexture("tripod_wood");
		SetTextureUVScale(1.0, 1.0);
		SetShaderMaterial("wood");


		// draw the mesh with transformation values
		m_basicMeshes->DrawCylinderMesh();
	}

	/***********************************************************
	*  RenderTripodLegThree()
	*
	*  This method is called to render the shape for the 
	*  tripod leg
	***********************************************************/
	void SceneManager::RenderTripodLegThree()
	{
		// declare the variables for the transformations
		glm::vec3 scaleXYZ;
		float XrotationDegrees = 0.0f;
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;
		glm::vec3 positionXYZ;
		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(0.1f, 8.5f, 0.1f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 25.0f;
		YrotationDegrees = 180.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(0.0f, 0.0f, 3.0f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);
		
		SetShaderTexture("tripod_wood");
		SetTextureUVScale(1.0, 1.0);
		SetShaderMaterial("wood");


		// draw the mesh with transformation values
		m_basicMeshes->DrawCylinderMesh();
	}
	/***********************************************************
	*  RenderChain()
	*
	*  This method is called to render the shape for the chain
	*  connected to the intersection of the tripod legs and 
	*  the hook
	***********************************************************/
	void SceneManager::RenderChain()
	{
		// declare the variables for the transformations
		glm::vec3 scaleXYZ;
		float XrotationDegrees = 0.0f;
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;
		glm::vec3 positionXYZ;

		// Chain segment
		scaleXYZ = glm::vec3(0.05f, 2.2f, 0.05f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(0.0f, 4.2f, 0.0f);
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		
		SetShaderTexture("chain_hook_metal");
		SetTextureUVScale(1.0, 1.0);
		SetShaderMaterial("metal");

		m_basicMeshes->DrawCylinderMesh();
	}

	/***********************************************************
	*  RenderHook()
	*
	*  This method is called to render the hook connecting the 
	*  chain and the cookingpot.
	***********************************************************/
	void SceneManager::RenderHook()
	{
		// declare the variables for the transformations
		glm::vec3 scaleXYZ;
		float XrotationDegrees = 0.0f;
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;
		glm::vec3 positionXYZ;


		// Hook
		scaleXYZ = glm::vec3(0.2f);
		XrotationDegrees = 90.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;
		positionXYZ = glm::vec3(0.0f, 3.9f, 0.0f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	
		SetShaderTexture("chain_hook_metal");
		SetTextureUVScale(1.0, 1.0);
		SetShaderMaterial("metal");


		// draw the mesh with transformation values
		m_basicMeshes->DrawTorusMesh();
	}

	/***********************************************************
	*  RenderCookingPot()
	*
	*  This method is called to render the shape for the scene
	*  metal cooking pot object.
	***********************************************************/
	void SceneManager::RenderCookingPot()
	{
		// declare the variables for the transformations
		glm::vec3 scaleXYZ;
		float XrotationDegrees = 0.0f;
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;
		glm::vec3 positionXYZ;

		scaleXYZ = glm::vec3(1.0f, 0.7f, 1.0f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(0.0f, 3.5f, 0.0f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	
		SetShaderTexture("cooking_pot_metal");
		SetTextureUVScale(1.0, 1.0);
		SetShaderMaterial("metal");

		// draw the mesh with transformation values
		m_basicMeshes->DrawSphereMesh();
	}

	/***********************************************************
	*  RenderRopeLash()
	*
	*  This method draws the rope at the top of the tripod legs
	*  to make it look like they are tied together.
	***********************************************************/
	void SceneManager::RenderRopeLash()
	{
		glm::vec3 scaleXYZ;
		float XrotationDegrees = 90.0f;  
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;
		glm::vec3 positionXYZ = glm::vec3(0.0f, 6.6f, 0.0f); 

	
		scaleXYZ = glm::vec3(0.18);

		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		
		SetShaderTexture("rope");
		SetTextureUVScale(2.0, 1.0);
		SetShaderMaterial("wood"); 

		m_basicMeshes->DrawTorusMesh();
	}


		/***********************************************************
		*  The next 8 methods build the stone cirlce encompassing
		*  the cooking fire
		***********************************************************/

		/***********************************************************
		*  RenderStone1() - East
		***********************************************************/
		void SceneManager::RenderStone1()
		{
			glm::vec3 scaleXYZ = glm::vec3(0.5f, 0.4f, 0.7f);
			float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;
			glm::vec3 positionXYZ = glm::vec3(2.0f, 0.5f, 0.0f);

			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			SetShaderTexture("stone");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("stone");
			m_basicMeshes->DrawSphereMesh();
		}

		/***********************************************************
		 *  RenderStone2() - West
		 ***********************************************************/
		void SceneManager::RenderStone2()
		{
			glm::vec3 scaleXYZ = glm::vec3(0.5f, 0.4f, 0.7f);
			float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;
			glm::vec3 positionXYZ = glm::vec3(-2.0f, 0.5f, 0.0f);

			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			SetShaderTexture("stone");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("stone");
			m_basicMeshes->DrawSphereMesh();
		}

		/***********************************************************
		 *  RenderStone3() - North
		 ***********************************************************/
		void SceneManager::RenderStone3()
		{
			glm::vec3 scaleXYZ = glm::vec3(0.5f, 0.4f, 0.7f);
			float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;
			glm::vec3 positionXYZ = glm::vec3(0.0f, 0.5f, 2.0f);

			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			SetShaderTexture("stone");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("stone");
			m_basicMeshes->DrawSphereMesh();
		}

		/***********************************************************
		 *  RenderStone4() - South
		 ***********************************************************/
		void SceneManager::RenderStone4()
		{
			glm::vec3 scaleXYZ = glm::vec3(0.5f, 0.4f, 0.7f);
			float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;
			glm::vec3 positionXYZ = glm::vec3(0.0f, 0.5f, -2.0f);

			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			SetShaderTexture("stone");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("stone");
			m_basicMeshes->DrawSphereMesh();
		}

		/***********************************************************
		 *  RenderStone5() - NorthEast
		 ***********************************************************/
		void SceneManager::RenderStone5()
		{
			glm::vec3 scaleXYZ = glm::vec3(0.5f, 0.4f, 0.7f);
			glm::vec3 positionXYZ = glm::vec3(1.4f, 0.5f, 1.4f);

			SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
			SetShaderTexture("stone");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("stone");
			m_basicMeshes->DrawSphereMesh();
		}

		/***********************************************************
		 *  RenderStone6() - NorthWest
		 ***********************************************************/
		void SceneManager::RenderStone6()
		{
			glm::vec3 scaleXYZ = glm::vec3(0.5f, 0.4f, 0.7f);
			glm::vec3 positionXYZ = glm::vec3(-1.4f, 0.5f, 1.4f);

			SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
			SetShaderTexture("stone");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("stone");
			m_basicMeshes->DrawSphereMesh();
		}

		/***********************************************************
		 *  RenderStone7() - SouthEast
		 ***********************************************************/
		void SceneManager::RenderStone7()
		{
			glm::vec3 scaleXYZ = glm::vec3(0.5f, 0.4f, 0.7f);
			glm::vec3 positionXYZ = glm::vec3(1.4f, 0.5f, -1.4f);

			SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
			SetShaderTexture("stone");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("stone");
			m_basicMeshes->DrawSphereMesh();
		}

		/***********************************************************
		 *  RenderStone8() - SouthWest
		 ***********************************************************/
		void SceneManager::RenderStone8()
		{
			glm::vec3 scaleXYZ = glm::vec3(0.5f, 0.4f, 0.7f);
			glm::vec3 positionXYZ = glm::vec3(-1.4f, 0.5f, -1.4f);

			SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
			SetShaderTexture("stone");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("stone");
			m_basicMeshes->DrawSphereMesh();
		}


		/***********************************************************
		*  The next 3 functions draw the firewood for the cooking
		*  fire
		***********************************************************/
		/***********************************************************
		*  RenderFirewood1()
		*
		*  This method draws the firewood in a collapsed teepee
		***********************************************************/
		void SceneManager::RenderFirewood1()
		{
			glm::vec3 scaleXYZ;
			float XrotationDegrees = 60.0f;  
			float YrotationDegrees = 45.0f;
			float ZrotationDegrees = 0.0f;
			glm::vec3 positionXYZ = glm::vec3(-0.5f, 0.0f, -0.7f); 

			// wood is drawn with log effect
			scaleXYZ = glm::vec3(0.2f, 1.0f, 0.2f);

			SetTransformations(
				scaleXYZ,
				XrotationDegrees,
				YrotationDegrees,
				ZrotationDegrees,
				positionXYZ);

			// use wood texture
			SetShaderTexture("tripod_wood");
			SetTextureUVScale(2.0, 1.0);
			SetShaderMaterial("wood"); // 

			m_basicMeshes->DrawCylinderMesh();
		}

		/***********************************************************
		*  RenderFirewood2()
		*
		*  This method draws the rope at the top of the tripod legs
		*  to make it look like they are tied together.
		***********************************************************/
		void SceneManager::RenderFirewood2()
		{
			glm::vec3 scaleXYZ;
			float XrotationDegrees = 60.0f;
			float YrotationDegrees = 140.0f;
			float ZrotationDegrees = 0.0f;
			glm::vec3 positionXYZ = glm::vec3(-0.5f, 0.0f, 0.5f);

			// wood is drawn to represent a log
			scaleXYZ = glm::vec3(0.2f, 1.0f, 0.2f);

			SetTransformations(
				scaleXYZ,
				XrotationDegrees,
				YrotationDegrees,
				ZrotationDegrees,
				positionXYZ);

			// use rope texture
			SetShaderTexture("tripod_wood");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("wood"); 

			m_basicMeshes->DrawCylinderMesh();
		}

		/***********************************************************
		*  RenderFirewood3()
		*
		*  This method draws the firewood in a collapsed teepee
		***********************************************************/
		void SceneManager::RenderFirewood3()
		{
			glm::vec3 scaleXYZ;
			float XrotationDegrees = 60.0f;
			float YrotationDegrees = 215.0f;
			float ZrotationDegrees = 0.0f;
			glm::vec3 positionXYZ = glm::vec3(0.5f, 0.0f, 0.5f);

			// wood is drawn to represent a log
			scaleXYZ = glm::vec3(0.2f, 1.0f, 0.2f);

			SetTransformations(
				scaleXYZ,
				XrotationDegrees,
				YrotationDegrees,
				ZrotationDegrees,
				positionXYZ);

			// use rope texture
			SetShaderTexture("tripod_wood");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("wood");

			m_basicMeshes->DrawCylinderMesh();
		}

		/***********************************************************
		*  RenderFirewood3()
		*
		*  This method draws the firewood in a collapsed teepee
		***********************************************************/
		void SceneManager::RenderSittingLog1()
		{
			glm::vec3 scaleXYZ;
			float XrotationDegrees = 90.0f;
			float YrotationDegrees = 45.0f;
			float ZrotationDegrees = 0.0f;
			glm::vec3 positionXYZ = glm::vec3(-3.0f, 0.0f, 2.0f);

			// wood is drawn to represent a log
			scaleXYZ = glm::vec3(0.5f, 2.5f, 0.5f);

			SetTransformations(
				scaleXYZ,
				XrotationDegrees,
				YrotationDegrees,
				ZrotationDegrees,
				positionXYZ);

			// use rope texture
			SetShaderTexture("tripod_wood");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("wood");

			m_basicMeshes->DrawCylinderMesh();
		}

		/***********************************************************
		*  RenderFirewood3()
		*
		*  This method draws the firewood in a collapsed teepee
		***********************************************************/
		void SceneManager::RenderSittingLog2()
		{
			glm::vec3 scaleXYZ;
			float XrotationDegrees = 90.0f;
			float YrotationDegrees = 315.0f;
			float ZrotationDegrees = 0.0f;
			glm::vec3 positionXYZ = glm::vec3(3.0f, 0.0f, 2.0f);

			// wood is drawn to represent a log
			scaleXYZ = glm::vec3(0.5f, 2.5f, 0.5f);

			SetTransformations(
				scaleXYZ,
				XrotationDegrees,
				YrotationDegrees,
				ZrotationDegrees,
				positionXYZ);

			// use rope texture
			SetShaderTexture("tripod_wood");
			SetTextureUVScale(1.0, 1.0);
			SetShaderMaterial("wood");

			m_basicMeshes->DrawCylinderMesh();
		}

		/***********************************************************
		*  RenderFlames()
		*
		*  
		***********************************************************/
		void SceneManager::RenderFlames()
		{
			float time = glfwGetTime();  // for flicker animation
			float flicker = (sinf(time * 10.0f) + 1.0f) * 0.5f; // oscillates 0�1

			// Flame color shifts between orange & yellow
			glm::vec3 flameColor = glm::vec3(1.0f, 0.5f + 0.3f * flicker, 0.0f);

			// Outer flame larger, more transparent
			glm::vec3 scaleOuter = glm::vec3(0.5f, 1.2f, 0.5f);
			glm::vec3 posOuter = glm::vec3(0.0f, 0.2f, 0.0f);
			SetTransformations(scaleOuter, 0.0f, 0.0f, 0.0f, posOuter);

			SetShaderColor(flameColor.r, flameColor.g, flameColor.b, 0.5f); // semi-transparent
			m_basicMeshes->DrawConeMesh();

			// Inner flame smaller, brighter
			glm::vec3 scaleInner = glm::vec3(0.3f, 0.8f + 0.1f * flicker, 0.3f);
			glm::vec3 posInner = glm::vec3(0.0f, 0.4f, 0.0f);
			SetTransformations(scaleInner, 0.0f, 0.0f, 0.0f, posInner);

			SetShaderColor(1.0f, 0.9f, 0.4f, 0.7f); // bright yellow-orange
			m_basicMeshes->DrawConeMesh();

			// Core flame (small, white-hot
			glm::vec3 scaleCore = glm::vec3(0.15f, 0.5f, 0.15f);
			glm::vec3 posCore = glm::vec3(0.0f, 0.6f, 0.0f);
			SetTransformations(scaleCore, 0.0f, 0.0f, 0.0f, posCore);

			SetShaderColor(1.0f, 1.0f, 0.8f, 0.8f);
			m_basicMeshes->DrawConeMesh();
		}


